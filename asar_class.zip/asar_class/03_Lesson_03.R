# install.packages("devtools")

devtools::install_github("bleutner/RStoolbox")
library(terra)
library(tmap)
library(sf)

# 

m = matrix(1:9, nrow = 3, ncol = 3)
m

r = rast(ncol = 3, nrow = 3, xmin = -150, xmax = -120, ymin = 20, ymax =50, vals = 1:9)

plot(r)

dem = rast("data/raster/dem.tif")

class(dem)

dim(dem)

ncell(dem)

nrow(dem)

ncol(dem)

res(dem)

cat(crs(dem))

hist(dem)

dem_WGS84 = project(dem, "EPSG:4326")

dem_WGS84

# Local

dem * 100

plot(dem >= 400)

# classify()

m = c(300, 400, 1, 400, 500, 2)
m = matrix(m, ncol = 3, byrow = T)
m
# right = TRUE (300, 400]

dem_reclass = classify(dem, m, right = TRUE)

dem_reclass

levels(dem_reclass) = data.frame(value = c(1,2), landform = c("plain", "plateu"))

cats(dem_reclass)


tm_shape(dem_reclass) +
  tm_raster()

# focal

dem_focal = focal(dem, w = matrix(1, nrow = 7, ncol = 7), fun = mean)

tm_shape(dem_focal) +
  tm_raster()

# contours 

tmap_mode(c("plot"))

contours = as.contour(dem_focal) %>% st_as_sf()
tm_shape(dem_focal) +
  tm_raster() +
  tm_shape(contours) +
  tm_lines()

## Zonal

geology = st_read("data/vect/data.gpkg", layer = "geology")

# rasterize
geology.ras = rasterize(vect(geology), dem, "SEDIMENTS")

geology.ras
plot(geology.ras)

zonal(dem, geology.ras, fun = "max")

# global

global(dem)

river = st_read("data/vect/data.gpkg", layer = "rimes_rivers")

dist.ras = distance(dem, vect(river))

tm_shape(dist.ras) +
  tm_raster(style = "cont") +
  tm_shape(river) +
  tm_lines()

terrain_char = terrain(dem, c("slope", "aspect", "TPI", "TRI"))

terrain_char
plot(terrain_char)

tpi.ras = terrain_char$TPI

# ndvi

# blue

blue = rast("data/raster/landsat_tbs/band_2.tif")

green = rast("data/raster/landsat_tbs/band_3.tif")

red = rast("data/raster/landsat_tbs/band_4.tif")

near.infrared = rast("data/raster/landsat_tbs/band_5.tif")

ndvi = (near.infrared - red) / (near.infrared + red)

plot(ndvi)

landsat = c(red, near.infrared)

indices = RStoolbox::spectralIndices(landsat, )

# write rasters

writeRaster(dist.ras, "data/raster/dist_raster.tif")


writeRaster(tpi.ras, "data/raster/tpi_raster.tif")

writeRaster(ndvi, "data/raster/ndvi_raster.tif")

install.packages("whitebox")

library(whitebox)
whitebox::install_whitebox()
wbt_version()


?wbt_geomorphons

whitebox::wbt_geomorphons(
  dem = "data/raster/dem.tif",
  output = "data/raster/geomorphons.tif"
)

geomorphons = rast("data/raster/geomorphons.tif")

plot(geomorphons)

tm_shape(geomorphons) +
  tm_raster(style = "cat")
