# Title: Notes from Lesson 0
# Author: Michal Michalski
# Date: 17-02-2023

# packages
# install.packages("stringr")
library(stringr)


# R as calculator ----

2 + 2

4^2

sqrt(16)

round(7.237, 2)

# 
area <- 4.815

pop_per_hectar <- 100

site_pop <- area * pop_per_hectar

site_pop

print(site_pop)

area <- 5

objects()

ls()

rm(area)

rm(list=ls())

size_ha <- c(7.56, 4.80, 10.5)

mean(size_ha, 0.5, TRUE)

?mean

mean(size_ha, )

str_sub("TBS_48_0_0", start = 1, end = 3)


# Data ----

as.character(8)

is.numeric(8)

site_id = c("TBS_1_0_0", "TBS_2_0_0", "TBS_3_0_0")

site_id

tell = c(TRUE, FALSE, FALSE)

tell

is.vector(site_id)

length(site_id)

str(site_id)

size_ha * 100

pop = size_ha * 100

size_ha[1]

size_ha[1:3]

period <- c("Iron Age", "Bronze Age", "Iron Age")

period <- factor(period)

period

levels(period)

TBS_24_0_0 = list(name = "TBS_24_0_0", size = c(16, 10, 2), periods = c("Late Branze Age", "Khabur", "Iron Age"), 
                  category = factor(c("town", "town", "hamlet")))

TBS_24_0_0[[1]]

TBS_24_0_0$size

m = matrix(1:9, nrow = 3, ncol = 3)
m
attributes(m)

dim(m)

array <- array(1:18, dim = c(3,3,2))

array

sites <- data.frame(site_id, size_ha, period)

sites$tell <- tell

sites[1,]
sites[1:2,]

sites[,1]

sites["site_id"]

sites$site_id

sites[sites$size_ha > 10,]

subset(sites, site_id == "TBS_1_0_0")

write.csv(sites, "data/sites.csv", row.names = FALSE)

sites_df <- read.csv("data/sites.csv")

sites_df_iron_age <- subset(sites_df, period == "Iron Age")

write.csv(sites_df_iron_age, "data/sites_iron_age.csv")
