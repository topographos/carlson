# Title: Lesson 1 
# packages

install.packages("dplyr")
library(sf)
library(terra)
library(tmap)
library(dplyr)

st_layers("data/vect/data.gpkg")

sites = st_read("data/vect/data.gpkg", layer = "sites_point")

head(sites)
str(sites)

plot(sites$geom)

# raster

dem = rast("data/raster/dem.tif")

plot(dem, main = "DEM")

landsat = rast("data/raster/landsat_tbs/landsat.tif")

dem
landsat
plot(landsat)

plotRGB(landsat, r = "band_4", g = "band_3", b = "band_2", stretch = "lin")


tm_shape(dem) +
  tm_raster() +
  tm_shape(sites) +
  tm_bubbles(size = "size_ha")
