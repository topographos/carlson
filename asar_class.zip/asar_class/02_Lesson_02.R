library(sf)
library(dplyr)


site_id = c("TBS_1", "TBS_2", "TBS_3")

size_ha = c(18, 5.6,7.2)

sites = data.frame(site_id, size_ha)


p1 = st_point(c(5,2))

p2 = st_point(c(1,6))

p3 = st_point(c(1,6))

points_sfc = st_sfc(p1,p2,p3)


sites_sf = st_sf(sites, geometry = points_sfc)

sites_sf

plot(sites_sf)

# reading csv

tbs_sites = read.csv("data/tbs_sites.csv")
head(tbs_sites)

crs_wgs84 = st_crs(4326) 

class(crs_wgs84)

cat(crs_wgs84$wkt)

tbs_sites_sf = st_as_sf(tbs_sites, coords = c("longitude", "latitude"), crs = 4326)

st_write(tbs_sites_sf, "data/vect/data.gpkg", layer = "sites_point")

st_write(tbs_sites_sf, "data/vect/tbs_sites.shp")

# Attribute operations

rm(list = ls())

st_layers("data/vect/data.gpkg")

sites = st_read("data/vect/data.gpkg", layer = "sites_point")

s = sites[,c("id", "size_ha", "period")]


sites[sites$period == "Late Bronze Age",]

library(dplyr)

dplyr::filter(sites, period == "Late Bronze Age")

sites %>% 
  filter(period == "Late Bronze Age") %>%
  select(id)

sites %>% 
  group_by(period) %>% 
  summarise(
    total_area = sum(size_ha),
    n = n()
  ) %>% 
  st_drop_geometry()
  
# PART 2 ----
# packages
library(sf)
library(dplyr)
library(tmap)

# data

sites = st_read("data/vect/data.gpkg", layer = "sites_point")

# 

grid_sfc = st_make_grid(sites, cellsize = 2500)

# convert into sf
grid_sf = st_sf(grid_sfc)

grid_sf

st_geometry(grid_sf) = "geom"

grid_sf

plot(grid_sf)

grid_sf$grid_id = 1:nrow(grid_sf)

grid_sf

# map

tm_shape(grid_sf) +
  tm_borders() +
  tm_text("grid_id") +
  tm_shape(sites) +
  tm_symbols(col = "red")

# topological operator

sel_sgbp = st_intersects(x = grid_sf, y = sites)

sel_sgbp

# lenghts()

sel_logical = lengths(sel_sgbp) 

sel_logical

grid_with_sites = grid_sf[sel_logical,]



tm_shape(grid_with_sites) +
  tm_borders()

sel_count = lengths(sel_sgbp)

grid_sf$count = sel_count

grid_sf

tm_shape(grid_sf) +
  tm_polygons(col = "count")

# spatial join

grid_join = st_join(grid_sf, sites)

grid_sum = grid_join %>% 
  group_by(grid_id) %>% 
  summarize(
    count = n(),
    total_area = sum(size_ha)
  ) %>% 
  filter(!is.na(total_area))

# interactive map
tmap_mode(mode = c("plot"))

tm_shape(grid_sum) +
  tm_fill(col = "count", convert2density = TRUE, title = "Sites per km2") +
  tm_borders(alpha = 0.8, col = "white")

# geometry

rm(list = ls())

# 
sites_ltm = sites[sites$period == "Late Third Millennium",]

sites_buff_2km = st_buffer(sites_ltm, dist = 2000)

plot(sites_buff_2km$geom)

# union

sites_buff_2km_union =st_union(sites_buff_2km)

plot(sites_buff_2km_union)

class(sites_buff_2km_union)

agri_area = st_sf(sites_buff_2km_union)

st_geometry(agri_area) = "geom"

agri_area$area = st_area(agri_area)

agri_area

agri_area$area = units::set_units(st_area(agri_area), km^2)

agri_area

write_sf(agri_area, "data/data.gpkg", layer = "agri_area_ltm", delete_layer = TRUE)

st_layers("data/data.gpkg")
